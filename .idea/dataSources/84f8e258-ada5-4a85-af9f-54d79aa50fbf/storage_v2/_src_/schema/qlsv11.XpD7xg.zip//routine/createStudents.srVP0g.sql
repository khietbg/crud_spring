create
    definer = root@localhost procedure createStudents(IN newId varchar(10), IN newName varchar(255), IN newAge int,
                                                      IN newAddress varchar(255), IN newPhone varchar(10))
begin
       insert into students values (newId,newName,newAge,newAddress,newPhone);
end;

