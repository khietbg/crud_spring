create
    definer = root@localhost procedure deleteStudent(IN idDel varchar(10))
begin
    delete from students
    where id = idDel;
end;

