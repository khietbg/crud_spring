create
    definer = root@localhost procedure updateStudent(IN newName varchar(255), IN newAge int, IN newAddress varchar(255),
                                                     IN newPhone varchar(10), IN newId varchar(10))
begin
    update students
    set name = newName,
        age = newAge,
        address = newAddress,
        phone = newPhone
        where id = newId;
end;

