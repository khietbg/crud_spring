create
    definer = root@localhost procedure findById(IN idS varchar(10))
begin
    select * from students
    where id = idS;

end;

