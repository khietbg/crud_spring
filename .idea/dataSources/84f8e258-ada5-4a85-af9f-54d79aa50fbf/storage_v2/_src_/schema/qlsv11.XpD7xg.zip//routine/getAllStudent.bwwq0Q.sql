create
    definer = root@localhost procedure getAllStudent()
begin
    select * from students;
end;

