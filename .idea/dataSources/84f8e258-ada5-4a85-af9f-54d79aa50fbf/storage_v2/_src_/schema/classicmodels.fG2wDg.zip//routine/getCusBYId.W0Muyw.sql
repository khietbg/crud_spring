create
    definer = root@localhost procedure getCusBYId(IN cusNum int)
begin
select * from customers where customerNumber = cusNum;
end;

